/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espol.proyecto0907;

import ec.edu.espol.model.ListaOfertas;
import ec.edu.espol.model.Oferta;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static boolean verificarPlaca(String placa){
        String[] placaDividida = placa.split("-");
        boolean e = true;
        if (placaDividida[0].length()!=3){
            System.out.println("Error de ingreso de placa");
            e = false;
        }
        if (placaDividida[1].length()>4 && placaDividida[1].length()<3){
            System.out.println("Error de ingreso de placa");
            e  = false;
        }
        return e;
    }
    public static boolean validarInt(int valor,int max, int min){
        boolean e = true;
        if (valor<min){
            System.out.println("Error de ingreso");
            e = false;
        }
        if (valor>max){
            System.out.println("Error de ingreso");
            e = false;
        }
        return e;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        //menu 
        int x = 0;
        while (x == 0){
            System.out.println("Menú de opciones: \n 1. Vendedor \n 2. Comprador \n 3. Salir");
            Scanner s = new Scanner(System.in);
            ListaOfertas lista = new ListaOfertas();
            int intro = s.nextInt();
            if(intro == 1 && validarInt(intro,3,1)){
                Scanner sc = new Scanner(System.in);
                System.out.println("Ingrese su correo: ");
                String mail = sc.nextLine();
                System.out.println("Ingrese su clave: ");
                String clave = sc.nextLine();
                // verificar clave
                ListaOfertas ofertasParaVendedor = lista.filtarOfertasPorVendedor(mail);
                System.out.println("Ingrese la placa (formato AAA-000): ");
                String placa = sc.nextLine();
                verificarPlaca(placa);
                ListaOfertas ofertasPorPlaca = ofertasParaVendedor.filtarOfertasPorPlaca(placa);
                if (verificarPlaca(placa)){  
                    System.out.println(ofertasPorPlaca.getOfertas().get(0).getModelo() +"Precio: ");            
                    System.out.println("Se han realizado "+ ofertasPorPlaca.getOfertas().size()+ " ofertas");
                    for(int i=0; i< ofertasPorPlaca.getOfertas().size();){
                        System.out.println("Oferta "+ (i+1));
                        System.out.println("Correo: "+ ofertasPorPlaca.getOfertas().get(i).getCorreo());
                        System.out.println("Precio Ofertado: "+ ofertasPorPlaca.getOfertas().get(i).getValor());
                        if(i<=0){
                            System.out.println("1. Siguiente Oferta\n2. Aceptar Oferta");
                            int ingreso = sc.nextInt();
                            if(ingreso == 1 && validarInt(ingreso,2,1)){
                                i++;
                            }
                            if(ingreso == 2 && validarInt(ingreso,2,1)){
                                //mandar correo
                                //elimnar vehiculo del sistema
                                lista.removerOfertas(placa);

                            }                    
                        }
                        else {
                            System.out.println("1. Siguiente Oferta\n2. Anterior Oferta\n3. Aceptar Oferta");
                            int ingreso = sc.nextInt();
                            if(ingreso == 1 && validarInt(ingreso,3,1)){
                                i++;
                            }
                            if(ingreso == 2 && validarInt(ingreso,3,1)){
                                i--;
                            }
                            if(ingreso == 3 && validarInt(ingreso,3,1)){
                                //mandar correo 
                                //eliminar vehiculo
                                lista.removerOfertas(placa);
                            }
                        }

                    }
                }
            }
            if (intro == 2 && validarInt(intro,3,1)){
                //hacer ofertas
                //Criterios de busqueda 
                Scanner sc = new Scanner(System.in);
                System.out.println("Ingrese criterios de busqueda del carro que desea\n (Si el criterio no es necesario ingrese 0)");
                System.out.println("Tipo de vehiculo (Marca): ");
                String marca = sc.nextLine();
                System.out.println("Recorrido (minimo): ");
                int recorridoMin = sc.nextInt();
                System.out.println("Recorrido (maximo):");
                int recorridoMax = sc.nextInt();
                System.out.println("Año minimo: ");
                int añoMin = sc.nextInt();
                System.out.println("Año maximo: ");
                int añoMax = sc.nextInt();
                System.out.println("Precio minimo: ");  
                int precioMin = sc.nextInt();
                System.out.println("Precio maximo: ");
                int precioMax = sc.nextInt();
                //
                // esto de aqui es lo mimso pero adaptado con lo de vehiculos
                //for(int i=0; i< ofertasPorPlaca.getOfertas().size();){
                    System.out.println("Oferta "+ (i+1));
                    System.out.println("Correo: "+ ofertasPorPlaca.getOfertas().get(i).getCorreo());
                    System.out.println("Precio Ofertado: "+ ofertasPorPlaca.getOfertas().get(i).getValor());
                    if(i<=0){
                        System.out.println("1. Siguiente Oferta\n2. Aceptar Oferta");
                        if(sc.nextInt()== 1){
                            i++;
                        }
                        if(sc.nextInt()==2){
                            //mandar correo
                            //elimnar vehiculo del sistema
                            lista.removerOfertas(placa);

                        }                    
                    }
                    else {
                        System.out.println("1. Siguiente Oferta\n2. Anterior Oferta\n3. Aceptar Oferta");
                        if(sc.nextInt()== 1){
                            i++;
                        }
                        if(sc.nextInt()==2){
                            i--;
                        }
                        if(sc.nextInt()==3){
                            //mandar correo 
                            //eliminar vehiculo
                            lista.removerOfertas(placa);
                        }
                    }
                //}
            }
            if (intro == 3 && validarInt(intro,3,1)){
                x +=1;
            }
        }
    }
}
    
